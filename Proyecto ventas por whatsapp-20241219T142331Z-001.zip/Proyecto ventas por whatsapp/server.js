const express = require("express");
const cors = require("cors");
const mercadopago = require("mercadopago");

const app = express();
const PORT = 5001;

// Configurar MercadoPago con tu Access Token de prueba
mercadopago.configurations.setAccessToken("TEST-5039245334496260-121019-32235094ae64b8f992c7b34cd3bf5f87-246605165");

app.use(cors());
app.use(express.json());

// Ruta para generar la preferencia de pago
app.post("/create_preference", (req, res) => {
    const items = req.body.items;

    const preference = {
        items: items.map(item => ({
            title: item.title,
            quantity: item.quantity,
            unit_price: item.unit_price,
            currency_id: "COP"
        })),
        back_urls: {
            success: "http://localhost:3000/success",
            failure: "http://localhost:3000/failure",
            pending: "http://localhost:3000/pending",
        },
        auto_return: "approved"
    };

    // Crear la preferencia en MercadoPago
    mercadopago.preferences.create(preference)
        .then(response => {
            res.json({ init_point: response.body.init_point });
        })
        .catch(error => {
            console.error("Error en la creación de preferencia: ", error);
            if (error.response) {
                res.status(500).json({ error: error.response.data });
            } else {
                res.status(500).json({ error: error.message });
            }
        });
});

// Nueva ruta para obtener una preferencia de pago
app.get("/get_preference/:id", (req, res) => {
    const preferenceId = req.params.id;

    // Obtener la preferencia en MercadoPago
    mercadopago.preferences.get(preferenceId)
        .then(response => {
            res.json(response.body);
        })
        .catch(error => {
            console.error("Error al obtener la preferencia: ", error);
            if (error.response) {
                res.status(500).json({ error: error.response.data });
            } else {
                res.status(500).json({ error: error.message });
            }
        });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`http://127.0.0.1:5500/Proyecto_Tienda-mini_market/client/cart.html`);
});